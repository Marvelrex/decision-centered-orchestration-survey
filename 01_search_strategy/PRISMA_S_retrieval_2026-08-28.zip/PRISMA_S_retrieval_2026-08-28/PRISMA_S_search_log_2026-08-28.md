# PRISMA-S search log and PRISMA 2020 identification summary

**Search date:** 2026-08-28
**Time zone:** America/Edmonton (MDT)
**Final scope:** ACM Digital Library, IEEE Xplore, Scopus, DBLP, arXiv
**Protocol change:** Web of Science Core Collection was planned. After confirming that the current product menu does not include the Core Collection, the author decided on 2026-08-28 not to search that database in this round.
**Status:** Core and adjacent evidence searches were run in all five databases in the final scope.

## 1. Search principle

The core search combines three concept blocks as `A AND B AND C`. Adjacent evidence uses `(cloud OR "data center" OR edge OR serverless) AND B AND C`. It was run separately, recorded separately, and not merged into the core corpus.

- A, platform: `"container orchestration" OR "container scheduling" OR Kubernetes OR K8s OR "pod scheduling" OR "cloud-native" OR "serverless orchestration"`
- B, decision: `schedul* OR orchestrat* OR placement OR autoscal* OR routing OR migration OR provisioning OR consolidation OR "resource allocation"`
- C, sustainability: `carbon OR emission* OR energy OR power OR renewable OR water OR thermal OR sustainab* OR "embodied carbon"`

Beyond the coverage of each database itself, no year, language, or document-type limit was applied in this round. Results are reported per database. No cross-database total was computed, and no deduplication or screening was performed at this stage.

## 2. Identification summary by database

| Database | Set | Field and coverage | Limits | Raw hits | Exported | Export file |
|---|---|---|---|---:|---:|---|
| ACM Digital Library | Core | Anywhere/All, ACM Full-Text Collection | none | 3,327 | 0 | — |
| ACM Digital Library | Adjacent | Anywhere/All, ACM Full-Text Collection | none | 271,702 | 0 | — |
| IEEE Xplore | Core | All Metadata | All Results, no year, language, or content-type filter | 668 | 0 | — |
| IEEE Xplore | Adjacent | All Metadata | All Results, no year, language, or content-type filter | 31,925 | 0 | — |
| Scopus | Core | TITLE-ABS-KEY | none | 773 | 0 | — |
| Scopus | Adjacent | TITLE-ABS-KEY | none | 42,345 | 0 | — |
| Web of Science Core Collection | Core | Topic (`TS`), Core Collection planned | not searched by author decision | n/a | n/a | — |
| Web of Science Core Collection | Adjacent | Topic (`TS`), Core Collection planned | not searched by author decision | n/a | n/a | — |
| DBLP | Core | DBLP publication search, token prefix matching | none | 130 | 130 | `dblp_core_2026-08-28.json` |
| DBLP | Adjacent | DBLP publication search, token prefix matching | none | 3,183 | 3,183 | `dblp_adjacent_2026-08-28.json` |
| arXiv | Core | All fields, all classifications, cross-listed included | All dates, latest indexed version, no language limit | 88 | 88 | `arxiv_core_2026-08-28.json` |
| arXiv | Adjacent | All fields, all classifications, cross-listed included | All dates, latest indexed version, no language limit | 2,882 | 2,882 | `arxiv_adjacent_2026-08-28.json` |

**Important.** The table carries no database total row. Adjacent evidence is not a core database identification record and must not be added to the core counts without saying so.

## 3. Full search log by database

### 3.1 ACM Digital Library

**Interface and field:** Advanced Search, `field1=AllField` (Anywhere/All), `expand=dl` (The ACM Full-Text Collection).
**Coverage:** the page reports searching the ACM Full-Text Collection.
**Limits:** none. The 1987 to 2026 range shown on the page is the distribution of the results. Apply was not clicked, so it is not a preset year limit.

**Core query (3,327):**

```text
("container orchestration" OR "container scheduling" OR Kubernetes OR K8s OR "pod scheduling" OR "cloud-native" OR "serverless orchestration") AND (schedul* OR orchestrat* OR placement OR autoscal* OR routing OR migration OR provisioning OR consolidation OR "resource allocation") AND (carbon OR emission* OR energy OR power OR renewable OR water OR thermal OR sustainab* OR "embodied carbon")
```

**Adjacent query (271,702):**

```text
(cloud OR "data center" OR edge OR serverless) AND (schedul* OR orchestrat* OR placement OR autoscal* OR routing OR migration OR provisioning OR consolidation OR "resource allocation") AND (carbon OR emission* OR energy OR power OR renewable OR water OR thermal OR sustainab* OR "embodied carbon")
```

**Export:** 0. Institutional access reads the results, but the full set has no one-step export. Page-level citation export cannot cover 3,327 or 271,702 results, so no incomplete file was recorded as a formal export.

### 3.2 IEEE Xplore

**Interface and field:** Advanced Search, every term scoped to `All Metadata`. IEEE describes All Metadata as title, abstract, index terms, and related metadata fields.
**Limits:** All Results. No year, language, content-type, or subscribed-content filter was applied. The year range shown on the results page is only the distribution of the results.
**Access:** the page confirmed `Access provided by: University of Calgary`. Institutional access and an IEEE personal account are two separate states.

**Core query (668):**

```text
("All Metadata":"container orchestration" OR "All Metadata":"container scheduling" OR "All Metadata":Kubernetes OR "All Metadata":K8s OR "All Metadata":"pod scheduling" OR "All Metadata":"cloud-native" OR "All Metadata":"serverless orchestration") AND ("All Metadata":schedul* OR "All Metadata":orchestrat* OR "All Metadata":placement OR "All Metadata":autoscal* OR "All Metadata":routing OR "All Metadata":migration OR "All Metadata":provisioning OR "All Metadata":consolidation OR "All Metadata":"resource allocation") AND ("All Metadata":carbon OR "All Metadata":emission* OR "All Metadata":energy OR "All Metadata":power OR "All Metadata":renewable OR "All Metadata":water OR "All Metadata":thermal OR "All Metadata":sustainab* OR "All Metadata":"embodied carbon")
```

Result types: Conferences 520, Journals 112, Books 19, Magazines 11, Early Access Articles 6.

**Adjacent query (31,925):**

```text
("All Metadata":cloud OR "All Metadata":"data center" OR "All Metadata":edge OR "All Metadata":serverless) AND ("All Metadata":schedul* OR "All Metadata":orchestrat* OR "All Metadata":placement OR "All Metadata":autoscal* OR "All Metadata":routing OR "All Metadata":migration OR "All Metadata":provisioning OR "All Metadata":consolidation OR "All Metadata":"resource allocation") AND ("All Metadata":carbon OR "All Metadata":emission* OR "All Metadata":energy OR "All Metadata":power OR "All Metadata":renewable OR "All Metadata":water OR "All Metadata":thermal OR "All Metadata":sustainab* OR "All Metadata":"embodied carbon")
```

Result types: Conferences 21,635, Journals 8,712, Magazines 748, Books 401, Early Access Articles 376, Standards 53.

**Export:** 0. Bulk Export asks for an IEEE personal sign-in. What is verifiable here is UCalgary institutional access, not a personal bulk-export session, so no file was produced.

### 3.3 Scopus

**Interface and field:** Advanced document search, `TITLE-ABS-KEY` (title, abstract, author keywords, index keywords).
**Limits:** no year, language, document-type, or source-type limit.

**Core query (773):**

```text
TITLE-ABS-KEY(("container orchestration" OR "container scheduling" OR Kubernetes OR K8s OR "pod scheduling" OR "cloud-native" OR "serverless orchestration") AND (schedul* OR orchestrat* OR placement OR autoscal* OR routing OR migration OR provisioning OR consolidation OR "resource allocation") AND (carbon OR emission* OR energy OR power OR renewable OR water OR thermal OR sustainab* OR "embodied carbon"))
```

Visible type distribution includes Conference paper 420, Article 220, Conference review 96, Book chapter 21, Book 8. Remaining types were not used to infer the total. Language distribution: English 764, Chinese 9.

**Adjacent query (42,345):**

```text
TITLE-ABS-KEY((cloud OR "data center" OR edge OR serverless) AND (schedul* OR orchestrat* OR placement OR autoscal* OR routing OR migration OR provisioning OR consolidation OR "resource allocation") AND (carbon OR emission* OR energy OR power OR renewable OR water OR thermal OR sustainab* OR "embodied carbon"))
```

**Export:** 0. On the core results, a CSV export of all 773 records (citation information plus abstract and keywords) was attempted, then a 10-record RIS test on the current page. The export dialog closed without producing an observable or savable download. An initiated export was not recorded as a completed one. The same failing flow was not repeated on the adjacent results.

### 3.4 Web of Science Core Collection

**Planned field:** Topic (`TS`).
**Planned limits:** Core Collection, All years, no language or document-type limit. Index coverage would have been taken from the subscription page once reached.

**Planned core query, not run:**

```text
TS=("container orchestration" OR "container scheduling" OR Kubernetes OR K8s OR "pod scheduling" OR "cloud-native" OR "serverless orchestration") AND TS=(schedul* OR orchestrat* OR placement OR autoscal* OR routing OR migration OR provisioning OR consolidation OR "resource allocation") AND TS=(carbon OR emission* OR energy OR power OR renewable OR water OR thermal OR sustainab* OR "embodied carbon")
```

**Planned adjacent query, not run:**

```text
TS=(cloud OR "data center" OR edge OR serverless) AND TS=(schedul* OR orchestrat* OR placement OR autoscal* OR routing OR migration OR provisioning OR consolidation OR "resource allocation") AND TS=(carbon OR emission* OR energy OR power OR renewable OR water OR thermal OR sustainab* OR "embodied carbon")
```

**Status:** not run, no raw hits obtained, nothing exported. After authentication the Web of Science product menu still did not include the Core Collection, and the reachable Researcher Search page is not the Core Collection database. The author then decided not to search Web of Science in this round. The database is therefore outside the final scope, its hit and export counts are recorded as not applicable, and they must not be written as 0 or inferred from the other databases. The queries above are kept as a record of the plan and must not be described as executed.

### 3.5 DBLP

**Interface and field:** DBLP publication search. DBLP no longer supports general phrase search. A space means AND, a vertical bar means OR, and ordinary tokens use prefix matching. To adapt faithfully to DBLP syntax the phrases were split into searchable tokens, and `data center` was conservatively rewritten as `data` in the adjacent query.
**Limits:** none.

**Core query (130):**

```text
container|kubernetes|k8s|pod|serverless schedul|orchestrat|placement|autoscal|routing|migration|provisioning|consolidation|allocation carbon|emission|energy|power|renewable|water|thermal|sustainab|embodied
```

**Adjacent query (3,183):**

```text
cloud|data|edge|serverless schedul|orchestrat|placement|autoscal|routing|migration|provisioning|consolidation|allocation carbon|emission|energy|power|renewable|water|thermal|sustainab|embodied
```

**Export:** downloaded through the DBLP publication search API in batches of 100. Core took 2 batches (130 records), adjacent took 32 batches (3,183 records). `@total`, `@first`, and `@sent` were checked batch by batch before merging, and the record count in each merged file matches its raw hit count. No deduplication was performed.

### 3.6 arXiv

**Interface and field:** Advanced Search with three search rows, each set to `All fields`, joined by AND.
**Classification scope:** All classifications, cross-listed papers included.
**Dates and versions:** All dates. The page lists by announcement date, newest first. The export keeps the latest version number currently indexed by the search page and does not include historical versions.
**Other limits:** no language limit, 200 results per page, full abstracts shown.

**Core query (88):**

```text
all:("container orchestration" OR "container scheduling" OR Kubernetes OR K8s OR "pod scheduling" OR "cloud-native" OR "serverless orchestration") AND all:(schedul* OR orchestrat* OR placement OR autoscal* OR routing OR migration OR provisioning OR consolidation OR "resource allocation") AND all:(carbon OR emission* OR energy OR power OR renewable OR water OR thermal OR sustainab* OR "embodied carbon")
```

**Adjacent query (2,882):**

```text
all:(cloud OR "data center" OR edge OR serverless) AND all:(schedul* OR orchestrat* OR placement OR autoscal* OR routing OR migration OR provisioning OR consolidation OR "resource allocation") AND all:(carbon OR emission* OR energy OR power OR renewable OR water OR thermal OR sustainab* OR "embodied carbon")
```

**Export:** taken from the Advanced Search result pages, exactly as the interface returns them, rather than from a non-equivalent API rewrite that returns 62. Core is one page of 88. Adjacent is 15 pages, 200 per page for the first 14 and 82 on the last. Each page was checked against `Showing x-y of 2,882 results`, and arXiv IDs were checked for uniqueness with titles and URLs non-empty. The exported JSON carries the arXiv ID, current version number, title, authors, classifications, full abstract, submission history, comments, journal reference, DOI, and links.

## 4. Export file list

| File | Set | Records | Purpose |
|---|---|---:|---|
| `dblp_core_2026-08-28.json` | DBLP core | 130 | deduplication and title screening |
| `dblp_adjacent_2026-08-28.json` | DBLP adjacent | 3,183 | separate screening of adjacent evidence |
| `arxiv_core_2026-08-28.json` | arXiv core | 88 | deduplication and title or abstract screening |
| `arxiv_adjacent_2026-08-28.json` | arXiv adjacent | 2,882 | separate screening of adjacent evidence |

## 5. Notes for the PRISMA 2020 identification stage

This log gives per-database raw hit counts for ACM, IEEE, Scopus, DBLP, and arXiv, the five databases in the final scope. Web of Science Core Collection was not searched by author decision, and only the protocol-change record is kept. Adjacent evidence hits must not be merged into the core database identification counts. The following are kept separately:

1. the core raw hit count for each database
2. the adjacent raw hit count for each database
3. the record count actually loaded into the deduplication tool, with the corresponding file
4. automatic and manual duplicate counts, and the record count after deduplication
5. title and abstract exclusions, full-text assessments, full-text exclusion reasons, and the final included count

The final PRISMA 2020 flow diagram should not be drawn before every database export intended for the deduplication tool actually exists, and missing database hit counts should not be inferred from the number of references already held. The methodology should state plainly that five databases were searched and that Web of Science Core Collection was not run after the protocol change.
